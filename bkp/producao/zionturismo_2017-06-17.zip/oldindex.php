<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">

		<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame
		Remove this if you use the .htaccess -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

		<title>Zion Turismo</title>
		<meta name="description" content="Zion Turísmo">
		<meta name="author" content="Luis Paulo">
		<meta name="keywords" content="Zion Turísmo">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>

	<body>
		<div class="index">
			<div class="container">
				<div class="col-md-5 col-sm-6 form">
					<form method="post" id="frmIndex">
						<h3>Entre em contato conosco</h3>
						<div class="input-form">
							<input type="text" name="nome" class="form-control br0 mb10" placeholder="Nome" />
							<i class="icon-user-1"></i>
						</div>
						<div class="input-form">
							<input type="text" name="email" class="form-control br0 mb10" placeholder="E-mail" />
							<i class="icon-email"></i>
						</div>
						<div class="input-form">
							<input type="text" name="telefone" class="form-control br0 mb10" placeholder="Telefone" />
							<i class="icon-phone"></i>
						</div>
						<div class="input-form">
							<textarea name="texto" class="form-control br0 mb10 h120" placeholder="Mensagem" style="resize: none"></textarea>
							<i class="icon-pencil"></i>
						</div>						
					</form>
					<div class="clear"></div>
					<button class="btn btn-primary w100p ttu" id="enviarForm">Enviar</button>
				</div>
				<div class="col-md-7 col-sm-6 tac infos">
					<img src="img/logozion.png" class="w50p" />
					<h1>
						Em breve nosso novo Site estará no ar
					</h1>
					<h3>Ligue: (11) 4118-6261 / (435) 538-4455 / (407)967-7788</h3>
				
<br><br>
<a href="disney.php"><img src="img/destaque-disney.jpg" border=0></a>

</div>
			</div>
		</div>
		<div id="result_ajax"></div>
		<!-- Bootstrap -->
		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />	
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-fileinput.css">				
		<!-- Estilos padrões -->
		<link rel="stylesheet" href="css/00.css" />
		<link rel="stylesheet" href="css/animate.css" />
		<link rel="stylesheet" href="css/animation.css" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/responsivo.css" />	
		<!-- Fontello -->
		<link rel="stylesheet" href="fontello/css/fontello.css" />
		<!-- Fonts -->
		<link rel="stylesheet" href="font/font.css" />

		<!-- jQuery -->
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>		
		<!-- Bootstrap -->
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>		
		<script type="text/javascript" src="bootstrap/js/bootstrap-fileinput.js"></script>
		<!-- Wow Animations -->
		<script type="text/javascript" src="js/wow.min.js"></script>
		<!-- Functions -->
		<script type="text/javascript" src="js/functions.js"></script>
		<script>		
			new WOW().init();        		
       		$(document).ready(function(){
       			$('[data-toggle="tooltip"]').tooltip();
       			$('#enviarForm').click(function(){
       				var dados = $('#frmIndex').serialize();
       				$.ajax({
       					data: dados,
						type: 'POST',
						url: 'enviar.php',
						dataType: 'json',
						async: true,
						success:function(json){
							var msg = json.mensagem;
							if(msg == 1){
								$('#result_ajax').css('display','block').removeClass('result_no').addClass('result_yes');
								var result = document.getElementById("result_ajax");
								result.innerHTML="E-mail enviado com sucesso";
								respAjaxAnimation();
								window.location.href="";
							}else{
								$('#result_ajax').css('display','block').removeClass('result_yes').addClass('result_no');
								var result = document.getElementById("result_ajax");
								result.innerHTML= msg;
								respAjaxAnimation();
							}
						}
       				});
       			});
       		});
     	</script>
	</body>
</html>
		
